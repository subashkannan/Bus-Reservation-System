A Pen created at CodePen.io. You can find this one at https://codepen.io/pixelchar/pen/rfuqK.

 Mobile-first responsive and accessible data table. At narrower view ports, the thead is hidden, rows are turned into cards with labels shown using a data-* attribute.